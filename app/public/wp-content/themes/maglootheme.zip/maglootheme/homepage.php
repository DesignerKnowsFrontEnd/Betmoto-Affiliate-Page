<?php
/**
 * Template Name: Homepage
 *
 */



global $post;




get_header(); ?>


    <?php get_template_part( 'template-parts/landing-page/hero' ); ?>

    <?php get_template_part( 'template-parts/landing-page/whymoto' ); ?>

    <?php get_template_part( 'template-parts/landing-page/commission' ); ?>

    <?php get_template_part( 'template-parts/landing-page/faq' ); ?>

    <?php get_template_part( 'template-parts/landing-page/cta' ); ?>

    
<?php get_footer(); ?>