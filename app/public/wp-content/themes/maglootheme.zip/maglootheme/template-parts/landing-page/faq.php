<?php

/****** FAQ Section for Landing Page ******/

$faq = get_field('faq_section_items');

?>



<section id="faq">
    <div class="container">
        <div class="tri-header">
            <h2 class="green-text-long flex"><?php echo $faq['section_title']; ?></h2>
        </div>
        <div class="grid-container-2-faq">

        <?php 
            if(have_rows('faq_section_items')):
                while( have_rows('faq_section_items')): the_row();     
                    if(have_rows('faq_items')):   
                        while( have_rows('faq_items')): the_row(); 
                        
                    
        ?>
                                <div class="grid-items-faq">
                                    <div class="grid-items-faq-item">
                                        <div class="faq-num"><p><?php the_sub_field('faq_item_number'); ?></p></div>
                                        <div class="faq-text">
                                            <h4 class="green-text"><?php the_sub_field('faq_item_title'); ?></h4>
                                            <p><?php the_sub_field('faq_item_answer'); ?></p>
                                        </div>
                                    </div>
                                </div>
        <?php
                        endwhile;
                    endif;
                endwhile;
            endif; 
        ?>    

        </div>
    </div>
</section>