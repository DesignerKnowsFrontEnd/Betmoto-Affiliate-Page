<?php

/****** CommissionS Section for Landing Page ******/

$comm = get_field('commission_section_items');

?>

<section id="commission">
    <div class="container">
        <div class="single-header">
            <h2 class="green-text-single flex"><?php echo $comm['section_title']; ?></h2>
        </div>
        <div class="grid-container-2">
            <div class="grid-items-text">
                <p><?php echo $comm['paragraph_1']; ?></p>
                <br>
                <p><?php echo $comm['paragraph_2']; ?></p>
            </div>
            <div class="grid-items-table">
                <div class="grid-items-table-col-1">
                    <h4 class='green-text'><?php echo $comm['table_header_1']; ?></h4>
                    <?php 
                            if(have_rows('commission_section_items')):
                                while( have_rows('commission_section_items')): the_row();     
                                    if(have_rows('table_1')):   
                                        while( have_rows('table_1')): the_row(); 
                                        
                                        $item = get_sub_field('table_item');
        ?>
                                        <p><?php echo $item; ?></p>
        <?php
                        endwhile;
                    endif;
                endwhile;
            endif; 
        ?>
                   
                </div>
                <div class="grid-items-table-col-2">
                    <h4 class='green-text'><?php echo $comm['table_header_2']; ?></h4>
                    <?php 
                            if(have_rows('commission_section_items')):
                                while( have_rows('commission_section_items')): the_row();     
                                    if(have_rows('table_2')):   
                                        while( have_rows('table_2')): the_row(); 
                                        
                                        $item = get_sub_field('table_item');
        ?>
                                        <p><?php echo $item; ?></p>
        <?php
                        endwhile;
                    endif;
                endwhile;
            endif; 
        ?>
                </div>
            </div>
        </div>
    </div>
</section>