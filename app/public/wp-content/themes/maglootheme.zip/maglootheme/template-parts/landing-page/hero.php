<?php

/****** Hero Section for Landing Page ******/

$hero = get_field('hero_section_items');

?>

<section class="hero" style="background-image: url(<?php echo esc_url( $hero['hero_image']['url']); ?> );">
    <div class="container-xl flex-column flex-align-center">
        <div class="hero-content">
            <h1 class="title-32"><?php echo $hero['hero_title_1']; ?></h1>
            <h1 class="red-gradient-text title-64"><?php echo $hero['hero_title_2']; ?></h1>
            <h1 class="title-86"><?php echo $hero['hero_title_3']; ?></h1>
        </div>
        <a href="<?php echo esc_url( $hero['hero_button']['url'] ); ?>" class='btn btn-primary btn-cta large-btn'><?php echo $hero['hero_button']['title']; ?></a>
    </div>
</section>