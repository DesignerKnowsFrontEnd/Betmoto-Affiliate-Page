<?php

/****** CTA's Section for Landing Page ******/

$hero = get_field('hero_section_items');
$cta = get_field('cta_section_items');

?>


<section id="CTA">
    <div class="container">
        <div class="cta-wrapper">
            <h1 class="title-32"><?php echo $cta['cta_text_1']; ?></h1>
            <h1 class="red-gradient-text title-64"><?php echo $cta['cta_text_2']; ?></h1>
            <h1 class="title-86"><?php echo $cta['cta_text_3']; ?></h1>
            <a href="<?php echo esc_url( $hero['hero_button']['url'] ); ?>" class='btn btn-primary btn-cta cta-large-btn'><?php echo $hero['hero_button']['title']; ?></a>
        </div>
    </div>
</section>