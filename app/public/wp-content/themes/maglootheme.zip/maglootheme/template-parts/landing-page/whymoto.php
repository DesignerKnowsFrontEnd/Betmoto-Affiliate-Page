<?php

/****** Whymoto Section for Landing Page ******/

$why = get_field('why_betmoto_section_items');

?>

<section id="whymoto">
    <div class="container">
        <div class="tri-header">
            <h2 class="green-text flex"><?php echo $why['section_title']; ?></h2>
            <p><?php echo $why['paragraph']; ?></p>
        </div>
        <div class="grid-container-3">
        <?php 
            if(have_rows('why_betmoto_section_items')):
                while( have_rows('why_betmoto_section_items')): the_row();     
                    if(have_rows('card_items')):   
                        while( have_rows('card_items')): the_row(); 
                        
                        $image = get_sub_field('card_iconimage');
        ?>
                            <div class="grid-items">
                                <div class="grid-items-image-wrapper">
                                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_url($image['alt']); ?>">
                                </div>
                                <div class="grid-items-content">
                                    <h3 class="green-text"><?php the_sub_field('card_title'); ?></h3>
                                    <p><?php the_sub_field('card_paragraph'); ?></p>
                                </div>
                            </div>
        <?php
                        endwhile;
                    endif;
                endwhile;
            endif; 
        ?>

        </div>
        <div class="grid-container-2">
        <?php 
            if(have_rows('why_betmoto_section_items')):
                while( have_rows('why_betmoto_section_items')): the_row();     
                    if(have_rows('commission_card')):   
                        while( have_rows('commission_card')): the_row(); 
                        
                        $image2 = get_sub_field('image_or_icon');
        ?>
                    <div class="grid-items-horz">
                            <img src="<?php echo esc_url($image2['url']); ?>" alt="<?php echo esc_url($image2['alt']); ?>">
                        <div class="grid-items-horz-content">
                            <h3 class="green-text"><?php the_sub_field('title'); ?></h3>
                            <p><?php the_sub_field('sub_title'); ?></p>
                        </div>
                    </div>
            <?php
                        endwhile;
                    endif;
                endwhile;
            endif; 
        ?>
        </div>
    </div>
</section>
