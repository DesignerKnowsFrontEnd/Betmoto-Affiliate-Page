<?php 

$global = get_field('global_options', 'options');
$footer = get_field('footer_options', 'options');

?>



<footer id="contact">
    <div class="container">
        <div class="tri-header">
            <div class="footer-content">
                <h2 class="green-text flex"><?php echo $footer['footer_title']; ?></h2>
                <p><?php echo $footer['footer_paragraph']; ?></p>
                <a href="mailto:<?php echo $footer['email']; ?>" class="green-text"><?php echo $footer['email']; ?></a>
                <p>or</p>
                <p>Contact Us on Skype:</p>
                <a href="mailto:<?php echo $footer['skype']; ?>" class="green-text"><?php echo $footer['skype']; ?></a>
                <img src="<?php echo $global['site_logo']['url']; ?>" alt="<?php echo $global['site_logo']['alt']; ?>" class="footer-logo">
                <div class="copy">
                    <img src="<?php echo esc_url($footer['copy_image_1']['url']); ?>" alt="<?php echo esc_attr($footer['copy_image_1']['alt']); ?>">
                    <img src="<?php echo esc_url($footer['copy_image_2']['url']); ?>" alt="<?php echo esc_attr($footer['copy_image_2']['alt']); ?>">
                </div>
            </div>
        </div>
    </div>
</footer>



<?php wp_footer(); ?>

</body>

</html>