<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <?php get_template_part( 'template-parts/meta' ); ?>
    <?php wp_head();
    
    $global = get_field('global_options', 'options');
    $contact = get_field('contact_info', 'options');
    $social = get_field('social_icons', 'options'); 
    ?>
</head>


<body <?php body_class(); ?>>

<header id='navigation' class='header'>
    <div class="header-Logo">
           <img src="<?php echo $global['site_logo']['url']; ?>" alt="<?php echo $global['site_logo']['alt']; ?>" class="logo">
    </div>

    <?php
        $menuParameters = array(
            'menu' => 'primary_menu',
            'before'        => '',
            'after'     => '',
            'echo'            => false,
            'container'       => 'div',
            'container_class'       => 'header-Links',
            'depth'           => 0,
        );

echo strip_tags(wp_nav_menu( $menuParameters ), '<a><div>' );
?>
    <div class="header-CTA">
        <a href="<?php echo esc_url( $global['header_button_1']['url'] ); ?>" class='btn btn-background-offwhite btn-header'><?php echo $global['icon_html_string_for_button_1']; ?><?php echo $global['header_button_1']['title']; ?></a>
        <a href="<?php echo esc_url( $global['header_button_2']['url'] ); ?>" class='btn btn-primary btn-header'><?php echo $global['icon_html_string_for_button_2']; ?><?php echo $global['header_button_2']['title']; ?></a>
    </div>
    <div class="header-MobileBtn">
        <a href="javascript:void(0);" class="icon" onclick="openNav()">
                <i class="bi bi-list"></i>
        </a>
    </div>
</header>    

<div id='sidebarNav' class="sidebarNav">
    
    <div class="header-CloseBtn">
    <h2>Menu</h2>
            <a href="javascript:void(0);" class="closebtn" onclick="closeNav()">
                <i class="bi bi-x"></i>
            </a>
        </div>
    <div class="sidebarNav-flex">
    
           <?php
        $menuParameters = array(
            'menu' => 'primary_menu',
            'before'        => '',
            'after'     => '',
            'echo'            => false,
            'container'       => 'div',
            'container_class'       => 'sidebarNav-Links',
            'depth'           => 0,
        );

echo strip_tags(wp_nav_menu( $menuParameters ), '<a><div>' );
?>
    
    </div>
    
    <div class="sidebarNav-CTAs">
      
        <div class="header-CTA">
        <a href="<?php echo esc_url( $global['header_button_1']['url'] ); ?>" class='btn btn-background-offwhite btn-header'><?php echo $global['icon_html_string_for_button_1']; ?><?php echo $global['header_button_1']['title']; ?></a>
        <a href="<?php echo esc_url( $global['header_button_2']['url'] ); ?>" class='btn btn-primary btn-header'><?php echo $global['icon_html_string_for_button_2']; ?><?php echo $global['header_button_2']['title']; ?></a>
        </div>
    </div>
</div>



